import { title } from "@/components/primitives";

export default function CategoriesPage() {
	return (
		<div>
			<h1 className={title()}>Categories</h1>
		</div>
	);
}
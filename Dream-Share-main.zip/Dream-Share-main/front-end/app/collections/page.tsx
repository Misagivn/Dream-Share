import { title } from "@/components/primitives";

export default function CollectionsPage() {
	return (
		<div>
			<h1 className={title()}>Collections</h1>
		</div>
	);
}
import { title } from "@/components/primitives";

export default function SignUpPage() {
	return (
		<div>
			<h1 className={title()}>SignUp Page</h1>
		</div>
	);
}